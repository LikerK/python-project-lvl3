import os
import requests


def downloads(url, path=''):
    content = get_data_from_url(url)
    file_name = get_name_file(url)
    path_to_file = os.path.join(os.getcwd(), path, file_name)
    save_file(path_to_file, content)
    return path_to_file


def get_data_from_url(url):
    response = requests.get(url)
    return response.text


def save_file(path, content):
    with open(path, 'w') as file:
        file.write(content)


def get_name_file(url):
    url = url.replace('http://', '', 1)
    url = url.replace('https://', '', 1)
    url = url.replace('.', '-')
    url = url.replace('/', '-')
    return f'{url}.html'
